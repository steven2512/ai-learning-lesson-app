import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flame/text.dart'; // <-- for TextPaint
import 'package:flutter/material.dart';

class GenericButton<T> extends PositionComponent
    with TapCallbacks, HoverCallbacks {
  // ------------------ Required visuals ------------------
  final Vector2 buttonSize; // <<< REQUIRED
  final List<double> buttonPadding; // [top, right, bottom, left]
  final double fontSize;
  final double letterSpacing;
  final Color textColor;
  final FontWeight fontWeight;
  final double borderRadius;
  final Color buttonFillColor;
  double opacity; // 0..1

  // ------------------ Content ------------------
  final String label;

  // ------------------ Behavior ------------------
  final void Function(T value)? onPressed; // callbackFunction
  final T? payload; // argument to pass back

  // ------------------ Internal state ------------------
  bool _isHovered = false;
  bool _isPressed = false;

  late TextPaint _textPaint;

  GenericButton({
    required Vector2 position,
    required this.buttonSize,
    required this.label,
    required this.buttonPadding, // [t, r, b, l]
    required this.fontSize,
    required this.letterSpacing,
    required this.fontWeight,
    required this.textColor,
    required this.borderRadius,
    required this.buttonFillColor,
    this.opacity = 1.0,
    this.onPressed,
    this.payload,
    Anchor anchor = Anchor.topLeft,
    int? priority,
  }) : super(
         position: position,
         size: buttonSize,
         anchor: anchor,
         priority: priority ?? 0,
       ) {
    assert(
      buttonPadding.length == 4,
      'buttonPadding must be [top, right, bottom, left]',
    );
    _textPaint = TextPaint(
      style: TextStyle(
        fontSize: fontSize,
        letterSpacing: letterSpacing,
        fontWeight: fontWeight,
        color: textColor.withOpacity(opacity.clamp(0.0, 1.0)),
      ),
    );
  }

  // ------------------ Interaction ------------------
  @override
  void onTapDown(TapDownEvent event) {
    _isPressed = true;
    scale = Vector2.all(0.98); // tiny press feedback
  }

  @override
  void onTapUp(TapUpEvent event) {
    _isPressed = false;
    scale = Vector2.all(1.0);
    if (onPressed != null && payload != null) {
      onPressed!(payload as T);
    }
  }

  @override
  void onTapCancel(TapCancelEvent event) {
    _isPressed = false;
    scale = Vector2.all(1.0);
  }

  // FIX: HoverCallbacks signatures have NO params in this Flame version.
  @override
  void onHoverEnter() {
    _isHovered = true;
  }

  @override
  void onHoverLeave() {
    _isHovered = false;
    _isPressed = false;
  }

  // ------------------ Render ------------------
  @override
  void render(Canvas canvas) {
    super.render(canvas);

    final double baseOpacity = opacity.clamp(0.0, 1.0);
    final double hoverBoost = _isHovered ? 0.06 : 0.0;
    final double pressDarken = _isPressed ? 0.10 : 0.0;

    final rrect = RRect.fromRectAndRadius(
      Offset.zero & Size(size.x, size.y),
      Radius.circular(borderRadius),
    );

    // shadow
    final shadowPaint = Paint()
      ..color = Colors.black.withOpacity(0.18 * baseOpacity);
    canvas.drawRRect(rrect.shift(const Offset(0, 3)), shadowPaint);

    // fill
    final fill = buttonFillColor.withOpacity(
      (baseOpacity + hoverBoost).clamp(0.0, 1.0),
    );
    final fillPaint = Paint()..color = _darken(fill, pressDarken);
    canvas.drawRRect(rrect, fillPaint);

    // content rect (respect padding)
    final padTop = buttonPadding[0];
    final padRight = buttonPadding[1];
    final padBottom = buttonPadding[2];
    final padLeft = buttonPadding[3];
    final contentW = size.x - padLeft - padRight;
    final contentH = size.y - padTop - padBottom;

    // FIX: use TextPainter for measurement (no measureTextWidth/Height on TextPaint)
    final tp = _textPaint.toTextPainter(label)..layout(maxWidth: contentW);
    final textSize = tp.size;
    final textOffset = Offset(
      padLeft + (contentW - textSize.width) / 2,
      padTop + (contentH - textSize.height) / 2,
    );

    // draw text
    tp.paint(canvas, textOffset);
  }

  // ------------------ Utils ------------------
  Color _darken(Color c, double amount) {
    if (amount <= 0) return c;
    final hsl = HSLColor.fromColor(c);
    final darker = hsl.withLightness((hsl.lightness - amount).clamp(0.0, 1.0));
    return darker.toColor().withOpacity(c.opacity);
  }

  void setOpacity(double value) {
    opacity = value.clamp(0.0, 1.0);
    _textPaint = TextPaint(
      style: _textPaint.style.copyWith(color: textColor.withOpacity(opacity)),
    );
  }
}
