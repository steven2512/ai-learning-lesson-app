import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:running_robot/lesson_one.dart';

void main() {
  runApp(
    GameWidget(
      game: LessonOne(),
    ),
  );
}
