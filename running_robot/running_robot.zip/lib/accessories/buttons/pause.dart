// pause_button.dart
import 'dart:ui';
import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart' as m;
import 'package:flutter/material.dart';
import 'package:running_robot/accessories/events/event_type.dart';

class PauseButton extends PositionComponent
    with TapCallbacks, HasGameRef<FlameGame> {
  // Labels
  static const String _kTitle = 'Paused';
  static const String _kResume = 'Resume';
  static const String _kRestart = 'Restart';
  static const String _kMainMenu = 'Main Menu';

  // Bubble visuals
  static const double _defaultDiameter = 30;
  static const double _borderAlpha = 0.03;
  static const double _glassAlpha = 0.16;
  static const double _glassPressedBoost = 0.06;
  static const double _shadowAlpha = 0.01;
  static const double _haloAlpha = 0.035;

  static const Color _border = Color(0xFF0F172A);
  static const Color _iconColor = Color(0xFF111827);

  // Pressed feel
  static const double _pressOffset = 1.5;
  static const double _pressDarken = 0.05;
  static const double _pressHaloScale = 0.35;
  static const double _innerShadowEdgeStart = 0.74;

  // State
  bool _paused;
  bool _pressed = false;
  bool _visible = true;
  bool _overlayOpen = false;

  OverlayEntry? _overlayEntry;

  EventButton currentEvent = EventButton.unpressed;

  // Callbacks
  final VoidCallback onMainMenu;
  final VoidCallback? onRestart;
  final VoidCallback? onPause;
  final VoidCallback? onResume;

  // Ground cut-off & (kept for compat) screen height
  final double cutOffY; // y from top where ground begins
  final double screenHeight; // not strictly needed after the fix

  // Slide-out animation key
  final GlobalKey<_PauseSheetState> _sheetKey = GlobalKey<_PauseSheetState>();

  PauseButton({
    required Vector2 position,
    required this.onMainMenu,
    required this.cutOffY,
    required this.screenHeight,
    this.onRestart,
    this.onPause,
    this.onResume,
    double diameter = _defaultDiameter,
    bool startPaused = false,
  })  : _paused = startPaused,
        super(
          position: position,
          size: Vector2.all(diameter),
          anchor: Anchor.topRight,
          priority: 10000,
        );

  // Lifecycle
  @override
  Future<void> onLoad() async {
    if (_paused) {
      _openOverlayIfPossible();
      onPause?.call();
    }
  }

  @override
  void onRemove() {
    _hideOverlay();
    super.onRemove();
  }

  // External control
  void switchPhase(EventButton event) {
    currentEvent = event;
    if (event == EventButton.unpressed) _pressed = false;
  }

  void trigger() => _toggle();

  void setPaused(bool v) {
    if (_paused == v) return;
    _paused = v;
    if (_paused) {
      _openOverlayIfPossible();
      onPause?.call();
    } else {
      _hideOverlay();
      onResume?.call();
    }
  }

  void _toggle() => setPaused(!_paused);

  // Input
  @override
  void onTapDown(TapDownEvent event) => _pressed = true;
  @override
  void onTapCancel(TapCancelEvent event) => _pressed = false;
  @override
  void onTapUp(TapUpEvent event) {
    _pressed = false;
    _toggle();
  }

  // Overlay handling
  void _openOverlayIfPossible() {
    if (_overlayOpen) return;

    final ctx = game.buildContext;
    game.pauseEngine();

    if (ctx == null) {
      _overlayOpen = false;
      return;
    }

    _overlayEntry = OverlayEntry(builder: _buildOverlay);
    m.Overlay.of(ctx, rootOverlay: true).insert(_overlayEntry!);
    _overlayOpen = true;
  }

  m.Widget _buildOverlay(m.BuildContext context) {
    return Stack(
      children: [
        // Fill exactly from the ground to the bottom of the screen
        const Positioned.fill(child: SizedBox()), // keep Stack happy
        Positioned(
          top: cutOffY,
          left: 0,
          right: 0,
          bottom: 0, // ✅ gives tight constraints (no “not laid out”)
          child: _PauseSheet(
            key: _sheetKey,
            onClose: () {
              _resumeAction();
            },
            onRestart: () {
              _restartAction();
            },
            onMainMenu: () {
              _mainMenuAction();
            },
          ),
        ),
      ],
    );
  }

  Future<void> _hideOverlayAnimated() async {
    final st = _sheetKey.currentState;
    if (st != null) {
      await st.animateOut(); // ✅ don’t await null
    }
    _hideOverlay();
  }

  void _hideOverlay() {
    _overlayEntry?.remove();
    _overlayEntry = null;
    _overlayOpen = false;
  }

  // Actions
  Future<void> _resumeAction() async {
    await _hideOverlayAnimated();
    if (game.paused) game.resumeEngine();
    _paused = false;
    onResume?.call();
  }

  Future<void> _restartAction() async {
    onRestart?.call();
    await _resumeAction();
  }

  Future<void> _mainMenuAction() async {
    await _hideOverlayAnimated();
    if (game.paused) game.resumeEngine();
    _paused = false;
    onResume?.call();
    onMainMenu();
  }

  // Render bubble
  @override
  void render(Canvas canvas) {
    super.render(canvas);
    if (!_visible) return;

    final rect = Rect.fromLTWH(0, 0, size.x, size.y);
    final r = size.x / 2;
    final rrect = RRect.fromRectAndRadius(rect, Radius.circular(r));

    final double dy = _pressed ? _pressOffset : 0.0;
    canvas.save();
    canvas.translate(0, dy);

    if (!_pressed) {
      final shadow = Paint()
        ..color = const m.Color(0xFF000000).withOpacity(_shadowAlpha)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);
      canvas.save();
      canvas.translate(0, 1);
      canvas.drawRRect(rrect, shadow);
      canvas.restore();
    }

    final double fillOpacity =
        (_glassAlpha + (_pressed ? _glassPressedBoost : 0)).clamp(0.0, 1.0);

    final glass = Paint()
      ..blendMode = BlendMode.screen
      ..shader = const m.LinearGradient(
        begin: m.Alignment.topCenter,
        end: m.Alignment.bottomCenter,
        colors: [m.Colors.white, m.Colors.white],
      ).createShader(rect)
      ..color = m.Colors.white.withOpacity(fillOpacity);
    canvas.drawRRect(rrect, glass);

    if (_pressed) {
      final innerShadow = Paint()
        ..shader = m.RadialGradient(
          center: m.Alignment.center,
          radius: 0.95,
          colors: [m.Colors.transparent, m.Colors.black.withOpacity(0.18)],
          stops: [_innerShadowEdgeStart, 1.0],
        ).createShader(rect);
      canvas.drawRRect(rrect.deflate(1.2), innerShadow);
    }

    final glowPaint = Paint()
      ..blendMode = BlendMode.screen
      ..shader = const m.RadialGradient(
        center: m.Alignment(0, -0.15),
        radius: 0.85,
        colors: [m.Colors.white, m.Colors.transparent],
        stops: [0.0, 1.0],
      ).createShader(rect)
      ..color = m.Colors.white.withOpacity(fillOpacity * 0.65);
    canvas.drawRRect(rrect.deflate(1.0), glowPaint);

    if (_pressed) {
      final darken = Paint()
        ..color = const m.Color(0xFF000000).withOpacity(_pressDarken);
      canvas.drawRRect(rrect, darken);
    }

    final border = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0
      ..color = _border.withOpacity(_borderAlpha);
    canvas.drawRRect(rrect, border);

    final double haloAlpha =
        _pressed ? _haloAlpha * _pressHaloScale : _haloAlpha;
    final halo = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..color = _border.withOpacity(haloAlpha);
    canvas.drawRRect(rrect.inflate(1.0), halo);

    _paused ? _drawPlayIcon(canvas, 0.58) : _drawPauseIcon(canvas, 0.56);

    canvas.restore();
  }

  void _drawPauseIcon(Canvas canvas, double alpha) {
    final paint = Paint()..color = _iconColor.withOpacity(alpha);
    final w = size.x, h = size.y;
    final barW = w * 0.09;
    final gap = w * 0.11;
    final barH = h * 0.39;
    final top = (h - barH) / 2;
    final left1 = (w - (barW * 2 + gap)) / 2;
    final left2 = left1 + barW + gap;
    final r = Radius.circular(barW / 2);

    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(left1, top, barW, barH), r),
      paint,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(left2, top, barW, barH), r),
      paint,
    );
  }

  void _drawPlayIcon(Canvas canvas, double alpha) {
    final paint = Paint()..color = _iconColor.withOpacity(alpha);
    final w = size.x, h = size.y;
    final triW = w * 0.34;
    final triH = h * 0.40;
    final cx = w / 2 - w * 0.02, cy = h / 2;

    final path = Path()
      ..moveTo(cx - triW / 2, cy - triH / 2)
      ..lineTo(cx - triW / 2, cy + triH / 2)
      ..lineTo(cx + triW / 2, cy)
      ..close();
    canvas.drawPath(path, paint);
  }
}

// ────────────────────────────────────────────────────────────────
// Bottom sheet widget that fills area BELOW cutOffY and slides up
// ────────────────────────────────────────────────────────────────
class _PauseSheet extends StatefulWidget {
  final VoidCallback onClose;
  final VoidCallback onRestart;
  final VoidCallback onMainMenu;

  const _PauseSheet({
    required Key key,
    required this.onClose,
    required this.onRestart,
    required this.onMainMenu,
  }) : super(key: key);

  @override
  State<_PauseSheet> createState() => _PauseSheetState();
}

class _PauseSheetState extends State<_PauseSheet>
    with TickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 460));
  late final Animation<Offset> _slide =
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic)
          .drive(Tween(begin: const Offset(0, 1), end: Offset.zero));

  Future<void> animateOut() async {
    await _ctrl.reverse();
  }

  @override
  void initState() {
    super.initState();
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Force concrete size for SlideTransition via SizedBox.expand
    return ClipRect(
      child: SizedBox.expand(
        child: SlideTransition(
          position: _slide,
          child: Material(
            color: const Color.fromARGB(255, 67, 71, 80), // solid dark
            child: SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Grab bar
                    Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        width: 48,
                        height: 4,
                        decoration: BoxDecoration(
                          color: const Color(0xFF2A2F37),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),

                    // Header
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Paused',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close, color: Colors.white70),
                          splashRadius: 18,
                          onPressed: widget.onClose,
                        ),
                      ],
                    ),
                    const SizedBox(height: 25),

                    // Actions (compact vertical list)
                    _ActionRow(
                      icon: Icons.home_rounded,
                      label: 'Main Menu',
                      onTap: widget.onMainMenu,
                    ),
                    const SizedBox(height: 20),
                    _ActionRow(
                      icon: Icons.restart_alt_rounded,
                      label: 'Restart',
                      onTap: widget.onRestart,
                    ),
                    const SizedBox(height: 20),
                    _ActionRow(
                      icon: Icons.play_arrow_rounded,
                      label: 'Resume',
                      onTap: widget.onClose,
                    ),

                    const Spacer(), // elegant empty space; fits typical heights
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ActionRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _ActionRow({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Row(
          children: [
            // Icon chip
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: const Color(0xFF182027),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFF2A323A)),
              ),
              child: Icon(icon, color: const Color(0xFFB7C2CF)),
            ),
            const SizedBox(width: 12),
            Text(
              label,
              style: const TextStyle(
                color: Color(0xFFE7ECF2),
                fontSize: 20,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
