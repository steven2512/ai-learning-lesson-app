// lib/accessories/decorations/fancy_box.dart
//
// FancyBox — capsule header + rounded card + border + value (+ optional unit)
// PERF: pre-render static background (card + banner) to a raster,
// cache TextPainters/styles, only re-layout value text when it actually changes.
//
// Single-class change. Keeps your EventFancyBox + switchPhase flow.
// Starts hidden (EventFancyBox.hide). On EventFancyBox.animate: counts 0 -> target.
// On EventFancyBox.show: shows target immediately.

import 'dart:ui' as ui;
import 'package:flame/components.dart';
import 'package:flutter/material.dart' as m;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:running_robot/accessories/events/event_type.dart'; // EventFancyBox

class FancyBox extends PositionComponent {
  // ---- Config (keep your fields) ----
  final String titleText; // header (capsule)
  final int target; // count-up target integer
  final String? unit; // optional unit suffix like "%"

  /// [insideTintBase, bannerColor, borderColor]
  final List<m.Color> fillColors;

  /// [bannerFontSize, contentFontSize, iconSize]  (iconSize unused here, kept for parity)
  final List<double> fontSizes;

  /// [bannerTextColor, contentTextColor, iconColor] (iconColor unused here, kept for parity)
  final List<m.Color> fontColors;

  /// Corner radius of the main rounded card.
  final double cardRadius;

  /// Height of the header capsule.
  final double headerHeight;

  /// Padding inside the content area [top, right, bottom, left].
  final List<double> contentPadding;

  /// How long (seconds) to count 0 -> target on EventFancyBox.animate
  final double countDurationSec; // CHANGED: defaulted (non-breaking)

  // ---- Event state (your enum) ----
  EventFancyBox currentEvent = EventFancyBox.hide; // CHANGED

  // ---- Internal draw state ----
  bool _visible = false; // CHANGED
  double _animT = 0.0; // 0..1 progress for count-up
  int _shownValue = 0; // last painted integer
  String _shownText = '0'; // cached string (value + unit)

  // ---- Cached styles/layout ----
  late final m.TextStyle _bannerStyle; // CHANGED
  late final m.TextStyle _valueStyle; // CHANGED
  TextPainter? _bannerTp; // CHANGED
  TextPainter? _valueTp; // CHANGED

  // ---- Cached background raster (huge win) ----
  ui.Image? _bgRaster; // CHANGED
  bool _bgDirty = true; // CHANGED
  double _lastDpr = ui.PlatformDispatcher.instance.views.isNotEmpty
      ? ui.PlatformDispatcher.instance.views.first.devicePixelRatio
      : (ui.PlatformDispatcher.instance.implicitView?.devicePixelRatio ?? 1.0);

  FancyBox({
    required m.Offset positionPx, // absolute px position
    required this.titleText,
    required this.target,
    this.unit,
    required this.fillColors, // [insideTintBase, bannerColor, borderColor]
    required this.fontSizes, // [bannerFs, contentFs, iconSize]
    required this.fontColors, // [bannerText, contentText, iconColor]
    this.cardRadius = 20.0,
    this.headerHeight = 36.0,
    this.contentPadding = const [16, 16, 16, 16],
    this.countDurationSec = 0.8, // CHANGED: non-breaking, defaulted
    m.Size? boxSize, // total outer size; if null, auto from text
    Anchor anchor = Anchor.topLeft,
  }) : super(
          position: Vector2(positionPx.dx, positionPx.dy),
          size: boxSize != null
              ? Vector2(boxSize.width, boxSize.height)
              : Vector2.zero(),
          anchor: anchor,
        ) {
    assert(fillColors.length == 3,
        'fillColors = [insideTintBase, bannerColor, borderColor]');
    assert(
        fontSizes.length >= 2, 'fontSizes = [bannerFs, contentFs, iconSize]');
    assert(fontColors.length >= 2,
        'fontColors = [bannerText, contentText, iconColor]');
    assert(contentPadding.length == 4,
        'contentPadding = [top, right, bottom, left]');

    // ---- CHANGED: cache text styles (no per-frame GoogleFonts instantiation) ----
    _bannerStyle = GoogleFonts.lato(
      fontSize: fontSizes[0],
      fontWeight: m.FontWeight.w700,
      color: fontColors[0],
      height: 1.0,
    );
    _valueStyle = GoogleFonts.lato(
      fontSize: fontSizes[1],
      fontWeight: m.FontWeight.w800,
      color: fontColors[1],
      height: 1.0,
    );

    // Start hidden (your default)
    _visible = false;
    currentEvent = EventFancyBox.hide;
    _shownValue = 0;
    _shownText = unit == null ? '0' : '0$unit';
  }

  // ---- Public API like the rest of your app ----
  void switchPhase(EventFancyBox next) {
    // CHANGED
    currentEvent = next;
    if (next == EventFancyBox.hide) {
      _visible = false;
    } else if (next == EventFancyBox.show) {
      _visible = true;
      _animT = 1.0;
      _updateShownForT(); // set to target instantly
    } else if (next == EventFancyBox.animate) {
      _visible = true;
      _animT = 0.0; // start counting
      _updateShownForT();
    }
    // No need to rebuild banner/value styles; but background might need size
    _bgDirty = true;
  }

  // ---- Lifecycle ----
  @override
  void onGameResize(Vector2 gameSize) {
    super.onGameResize(gameSize);
    _bgDirty = true; // CHANGED
  }

  @override
  void onRemove() {
    _bgRaster?.dispose(); // CHANGED
    _bgRaster = null;
    super.onRemove();
  }

  // ---- Update: drive count-up only when animating ----
  @override
  void update(double dt) {
    super.update(dt);
    if (!_visible) return;
    if (currentEvent == EventFancyBox.animate) {
      if (_animT < 1.0) {
        final dur = countDurationSec <= 0 ? 0.001 : countDurationSec;
        _animT = (_animT + dt / dur).clamp(0.0, 1.0);
        _updateShownForT();
      }
    }
  }

  void _updateShownForT() {
    // CHANGED
    final int v = (_animT * target).round();
    if (v != _shownValue) {
      _shownValue = v;
      _shownText = unit == null ? '$v' : '$v$unit';
      _valueTp = null; // force re-layout only when value text actually changes
    }
  }

  // ---- Raster build for static background (card + banner) ----
  void _rebuildBackgroundRaster(Canvas? previewCanvas) {
    // CHANGED
    final double dpr = ui.PlatformDispatcher.instance.views.isNotEmpty
        ? ui.PlatformDispatcher.instance.views.first.devicePixelRatio
        : (ui.PlatformDispatcher.instance.implicitView?.devicePixelRatio ??
            1.0);

    // If size is zero, compute a minimal auto size from banner text
    // (keeps drop-in behavior if caller didn’t pass boxSize)
    _bannerTp ??= TextPainter(
      text: TextSpan(text: titleText, style: _bannerStyle),
      textAlign: TextAlign.center,
      textDirection: m.TextDirection.ltr,
      maxLines: 1,
      ellipsis: '…',
    )..layout(maxWidth: double.infinity);

    final double minWidth =
        (_bannerTp!.width + 24.0).clamp(120.0, double.infinity);
    if (size.x <= 0 || size.y <= 0) {
      // default height = header + content + paddings
      final double h =
          headerHeight + contentPadding[0] + fontSizes[1] + contentPadding[2];
      size = Vector2(minWidth, h);
    } else {
      // ensure at least wide enough for banner text
      if (size.x < minWidth) size.x = minWidth;
    }

    final int pxW = (size.x * dpr).ceil().clamp(1, 100000);
    final int pxH = (size.y * dpr).ceil().clamp(1, 100000);

    final recorder = ui.PictureRecorder();
    final ui.Canvas c = ui.Canvas(recorder);

    // Draw in logical units; scale for crisp raster
    c.save();
    c.scale(dpr, dpr);

    final m.Color inside = fillColors[0];
    final m.Color banner = fillColors[1];
    final m.Color border = fillColors[2];

    final m.Paint fillPaint = m.Paint()
      ..isAntiAlias = true
      ..color = inside;

    final m.Paint borderPaint = m.Paint()
      ..isAntiAlias = true
      ..style = m.PaintingStyle.stroke
      ..strokeWidth = 2
      ..color =
          border.withOpacity(border.opacity); // avoid withOpacity churn later

    // CARD
    final rrect = RRect.fromRectAndRadius(
      m.Rect.fromLTWH(0, 0, size.x, size.y),
      m.Radius.circular(cardRadius),
    );
    c.drawRRect(rrect, fillPaint);
    c.drawRRect(rrect, borderPaint);

    // HEADER CAPSULE
    final double capW = (size.x * 0.66).clamp(96.0, size.x - 16.0);
    final double capX = (size.x - capW) / 2.0;
    final m.RRect cap = m.RRect.fromRectAndRadius(
      m.Rect.fromLTWH(capX, -headerHeight / 2.0, capW, headerHeight),
      m.Radius.circular(headerHeight / 2.0),
    );
    final m.Paint capPaint = m.Paint()..color = banner;
    c.drawRRect(cap, capPaint);
    // Banner label
    final double bannerMaxWidth = capW - 12.0;
    _bannerTp ??= TextPainter(
      text: TextSpan(text: titleText, style: _bannerStyle),
      textAlign: TextAlign.center,
      textDirection: m.TextDirection.ltr,
      maxLines: 1,
      ellipsis: '…',
    )..layout(maxWidth: bannerMaxWidth);
    final double bdx = capX + (capW - _bannerTp!.width) / 2.0;
    final double bdy =
        -headerHeight / 2.0 + (headerHeight - _bannerTp!.height) / 2.0;
    _bannerTp!.paint(c, m.Offset(bdx, bdy));

    c.restore();

    final picture = recorder.endRecording();
    _bgRaster?.dispose();
    _bgRaster = picture.toImageSync(pxW, pxH);
    _lastDpr = dpr;
    _bgDirty = false;
  }

  // ---- Render ----
  @override
  void render(ui.Canvas canvas) {
    if (!_visible) return;

    // Rebuild background if needed or DPR changed
    final double dpr = ui.PlatformDispatcher.instance.views.isNotEmpty
        ? ui.PlatformDispatcher.instance.views.first.devicePixelRatio
        : (ui.PlatformDispatcher.instance.implicitView?.devicePixelRatio ??
            1.0);

    if (_bgRaster == null || _bgDirty || (dpr - _lastDpr).abs() > 1e-6) {
      _rebuildBackgroundRaster(canvas); // CHANGED
    }
    if (_bgRaster == null) return;

    // Draw background raster (card + banner) in one call
    final src = m.Rect.fromLTWH(
        0, 0, _bgRaster!.width.toDouble(), _bgRaster!.height.toDouble());
    final dst = m.Rect.fromLTWH(0, 0, size.x, size.y);
    canvas.drawImageRect(_bgRaster!, src, dst, m.Paint());

    // ----- VALUE TEXT -----
    // Layout only if text changed (during count or unit/title change)
    _valueTp ??= TextPainter(
      text: TextSpan(text: _shownText, style: _valueStyle),
      textAlign: TextAlign.center,
      textDirection: m.TextDirection.ltr,
      maxLines: 1,
      ellipsis: '…',
    )..layout(maxWidth: size.x - contentPadding[1] - contentPadding[3]);

    // Center value in content area (below capsule), respecting padding
    final double innerX = contentPadding[3];
    final double innerY = contentPadding[0] + headerHeight * 0.5;
    final double innerW = size.x - contentPadding[1] - contentPadding[3];
    final double innerH = size.y - innerY - contentPadding[2];

    final double vdx = innerX + (innerW - _valueTp!.width) / 2.0;
    final double vdy = innerY + (innerH - _valueTp!.height) / 2.0;

    // If _valueTp is stale (because _shownText changed), re-layout now
    if (_valueTp!.text?.toPlainText() != _shownText) {
      _valueTp = m.TextPainter(
        text: m.TextSpan(text: _shownText, style: _valueStyle),
        textAlign: TextAlign.center,
        textDirection: m.TextDirection.ltr,
        maxLines: 1,
        ellipsis: '…',
      )..layout(maxWidth: innerW);
    }

    _valueTp!.paint(canvas, m.Offset(vdx, vdy));
  }
}
