// lib/ui/end_lesson_overlay.dart
import 'dart:ui';
import 'package:flutter/material.dart';

class EndLessonData {
  final int stars; // 0..3
  final int score;
  final Duration time;
  final String? summary;
  const EndLessonData({
    required this.stars,
    required this.score,
    required this.time,
    this.summary,
  });
}

class EndLessonOverlay extends StatefulWidget {
  static const String id = 'LessonEnd';

  final EndLessonData data;
  final VoidCallback onRetry;
  final VoidCallback onNext;
  final VoidCallback onExit;

  const EndLessonOverlay({
    super.key,
    required this.data,
    required this.onRetry,
    required this.onNext,
    required this.onExit,
  });

  @override
  State<EndLessonOverlay> createState() => _EndLessonOverlayState();
}

class _EndLessonOverlayState extends State<EndLessonOverlay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  // Helper to build a staggered scale/opacity for star i (0..2).
  Animation<double> _scaleFor(int i) => Tween(begin: 0.0, end: 1.0).animate(
    CurvedAnimation(
      parent: _ctrl,
      curve: Interval(
        i * 0.25,
        (i * 0.25 + 0.6).clamp(0.0, 1.0),
        curve: Curves.elasticOut,
      ),
    ),
  );

  Animation<double> _fadeFor(int i) => Tween(begin: 0.0, end: 1.0).animate(
    CurvedAnimation(
      parent: _ctrl,
      curve: Interval(
        i * 0.25,
        (i * 0.25 + 0.35).clamp(0.0, 1.0),
        curve: Curves.easeOut,
      ),
    ),
  );

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mm = (widget.data.time.inSeconds ~/ 60).toString().padLeft(2, '0');
    final ss = (widget.data.time.inSeconds % 60).toString().padLeft(2, '0');

    return Stack(
      children: [
        // Dim + blur the running game behind
        Positioned.fill(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
            child: Container(color: Colors.black.withOpacity(0.45)),
          ),
        ),
        Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 10,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'Lesson Complete!',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 8),
                    // Stars (animate only the earned ones)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(3, (i) {
                        final filled = i < widget.data.stars;
                        if (!filled) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            child: Icon(
                              Icons.star_border,
                              size: 28,
                              color: Colors.grey.shade400,
                            ),
                          );
                        }
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: FadeTransition(
                            opacity: _fadeFor(i),
                            child: ScaleTransition(
                              scale: _scaleFor(i),
                              child: const Icon(
                                Icons.star,
                                size: 28,
                                color: Color(0xFFFFC107),
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                    const SizedBox(height: 12),
                    // Score & time
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.timer, size: 18),
                        const SizedBox(width: 6),
                        Text('$mm:$ss', style: const TextStyle(fontSize: 16)),
                        const SizedBox(width: 16),
                        const Icon(Icons.emoji_events, size: 18),
                        const SizedBox(width: 6),
                        Text(
                          '${widget.data.score}',
                          style: const TextStyle(fontSize: 16),
                        ),
                      ],
                    ),
                    if ((widget.data.summary ?? '').isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Text(
                        widget.data.summary!,
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey.shade700),
                      ),
                    ],
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: widget.onRetry,
                            child: const Text('Retry'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: widget.onNext,
                            child: const Text('Next Lesson'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    TextButton(
                      onPressed: widget.onExit,
                      child: const Text('Exit'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
