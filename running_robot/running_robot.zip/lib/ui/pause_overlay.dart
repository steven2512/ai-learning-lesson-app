import 'package:flutter/material.dart';

class PauseOverlay extends StatelessWidget {
  final VoidCallback onResume;
  const PauseOverlay({required this.onResume, super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black54,
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ElevatedButton(onPressed: onResume, child: const Text("Resume")),
            ElevatedButton(
                onPressed: () {/* navigate main menu */},
                child: const Text("Exit")),
          ],
        ),
      ),
    );
  }
}
